import sys

filename = "Pygreetings%s.txt" % sys.argv[1]
ofile = open(filename, "a")
ofile.write("Hello %s, this message is brought to you by Python code!\n" % sys.argv[1])
ofile.close()
print "File created: %s" % filename
