greet <- function(name) {
  path <- paste(system.file(package="Pydemo"), "Pygreet.py", sep="/")
  command <- paste("python", path, name)
  system(command)
}
