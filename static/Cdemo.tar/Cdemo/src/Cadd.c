void Caddone(double *x, int *length) {
  for(int i=0; i<*length; i++) {
    x[i] = x[i]+1;
  }
}

