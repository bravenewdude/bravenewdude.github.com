addone <- function(x) {
  x <- as.double(x)
  .C("Caddone", DUP=F, x, length(x))
  return(x)
}